<?php
// Config settings
define('STRIPE_REQUIRE_HTTPS', true);
define('STRIPE_API_KEY', 'sk_test_51Kh8f8CrxE19p0jxqmyflCiNQrBYMoqTtkHyvTXZYJstgq7H9Il8MaQXZPcBRazt4VY9Uvub6tYo388tZwsEiNzQ00YAF9CzdW');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51Kh8f8CrxE19p0jxe0TazunvyNdkQ8VpqboTwERBnwaIZyEgvmcLANmFqQEu9wRYYDqeT6FwTMCkcIbVoEdPesj300pssaZpPW');
